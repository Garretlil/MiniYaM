package com.example.miniyam

const val BASEURL: String ="http://10.0.2.2:8080"